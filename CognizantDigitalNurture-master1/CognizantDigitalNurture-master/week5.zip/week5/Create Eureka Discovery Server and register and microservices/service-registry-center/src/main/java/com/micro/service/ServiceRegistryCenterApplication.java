package com.micro.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRegistryCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRegistryCenterApplication.class, args);
	}

}
