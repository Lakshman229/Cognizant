package com.micro.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanProcessingService1Application {

	public static void main(String[] args) {
		SpringApplication.run(LoanProcessingService1Application.class, args);
	}

}
