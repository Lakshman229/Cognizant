package com.micro.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountManagementService1Application {

	public static void main(String[] args) {
		SpringApplication.run(AccountManagementService1Application.class, args);
	}

}
