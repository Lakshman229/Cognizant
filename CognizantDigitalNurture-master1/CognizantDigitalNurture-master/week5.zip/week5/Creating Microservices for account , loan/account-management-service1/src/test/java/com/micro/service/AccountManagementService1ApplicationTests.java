package com.micro.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountManagementService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
